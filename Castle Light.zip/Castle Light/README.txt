Castle Light the video game

Welcome to Castle Light, a brand-new tower defence game with a twist....

- Choose your land
- Place your towers
- Cast a spell
- Defeat the enemies

With 4 towers to place, 3 spells to master, 3 levels you can chose from. 

Can you stop the waves of enemies and survive the mighty boss?

## How to play ##
1) Once the level has been selected, a random deck of cards will be assigned at the bottom of the screen
2) The player can test their luck and discard their cards getting 50% + currency points of what the card was worth and draw a new card
3) This is done by selecting the card chosen to be discarded and clicking on the discard button.
4) Once the player is satisfied with the cards, they can place the towers on the selected zones on the map. These are distinguishable as they were made to stand out on the map.
5) To place the tower, select the tower card by clicking on the card. This selects the card which then the user can place on any of the selected zones on the map.
6) To use the spells, the user has to select the spell card of their choice. If a card is selected, a red area marker is displayed which allows the player to hover over the area where they would like to cast the spell and select it.
7) Destroy your enemies no matter what but be careful with your currency as you will leave your kingdom vulnerable.
